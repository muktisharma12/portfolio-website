# omeglin

Source code for the Omeglin app from https://javalin.io/tutorials/building-an-omegle-clone-in-javalin. 

Omeglin is a simple and fully functional Omegle clone built in Javalin, 
using plain JavaScript and CSS (no libraries or frontend build pipeline).

<img width="1003" alt="Omeglin" src="https://github.com/tipsy/omeglin/assets/1521451/33415a5f-95b7-47a4-90a1-b199e075a714">
